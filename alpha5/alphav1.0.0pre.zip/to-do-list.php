<a href="admin.php">Back</a>
<table border="1">
	  <tr>
		<td colspan="4"><b>Next in Development:</b></td>
	  </tr>
		<tr>
			<td><i>Release Version: &nbsp &nbsp &nbsp &nbsp </i></td>
			<td><i>Appx. Time of Release: &nbsp &nbsp &nbsp </i></td>
            <td><i>Changes: &nbsp </i></td>
            <td><i>Developing By: &nbsp </i></td>
		</tr>
		<tr>
			<td><i>Alpha v1.0.0RC6/7 or Alpha6/7</i></td>
			<td><i>~ September 25/26, 2013</i></td>
            <td><i>- Improved Install.PHP checking if there is a Database connection or not then asking you to input.<br/>- Improved Admin Section with either full site view or Admin Panel view.<br/>- Editing Posts<br/>- Config.PHP for allow register, allow posting, site matainance. (I'll make more just not in the next update).<br/>- More Colorful and better styling with Default.CSS.<br/>- Improved posting where php submits the exact time.<br/>- Favicon.<br/>- Fixes</i></td>
            <td><i>Harry</i></td>
		</tr>
		<tr>
			<td><i>Alpha v1.0.0</i></td>
			<td><i>October 14, 2013</i></td>
            <td><i>First Public Release</i></td>
            <td><i>Eric and Harry</i></td>
		</tr>
</table>