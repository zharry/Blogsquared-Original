<a href="admin.php">Back</a><table border="1">
	  <tr>
		<td colspan="3"><b>Release Log:</b></td>
	  </tr>
          <tr>
		<td><i>Time/Date of Release: &nbsp &nbsp &nbsp &nbsp </i></td>
		<td><i>Releases and Changes: &nbsp &nbsp &nbsp </i></td>
                <td><i>Released By: &nbsp </i></td>
	  </tr>
          <tr>
		<td>7:00 September, 04, 2013</td>
		<td>+ Random-Blog.TK Site Created!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>4:00 September, 05, 2013</td>
		<td>+ Tests 1,2,3 Finish! Alpha 1 Begins! Starting Fresh!</td>
                <td>Harry and Eric</td>
	  </tr>
          <tr>
		<td>4:05 September ,05, 2013</td>
		<td>+ New Index.PHP created.</td>
                <td>Harry and Eric</td>
	  </tr>
          <tr>
		<td>6:25 September ,05, 2013</td>
		<td>+ Added Toggle Release Log</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>2:30PM September 15, 2013</td>
		<td>+ Entire Login System Finished</td>
                <td>Eric</td>
	  </tr>
          <tr>
		<td>2:45PM September 15, 2013</td>
		<td>- Useless Stuff Like The Original Parse Files</td>
                <td>Eric</td>
	  </tr>
          <tr>
		<td>1:00PM September 16, 2013</td>
		<td>- Name changed from Myrandomblog to Random-Blog to Blog Squared (BS)</td>
                <td>Eric and Harry</td>
	  </tr>
          <tr>
		<td>8:00PM September 20, 2013</td>
		<td>- Started Migration from Old Style to New Style</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>9:30PM September 20, 2013</td>
		<td>- Install.PHP Finished</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>9:50PM September 20, 2013</td>
		<td>- Register.PHP, Login.PHP, Logout.PHP, Edit-Account.PHP modified to fit Install.PHP</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>10:05PM September 20, 2013</td>
		<td>- Index.PHP Get's it's First Renovation</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>11:15AM September 21, 2013</td>
		<td>- Index.PHP Cobines the Previous Index Page with Admin Panel.</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>11:15AM September 15, 2013</td>
		<td>- New Style.CSS (with almost Nothing in it)-Progress towards custom styles.</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>11:20AM September 21, 2013</td>
		<td>- Offline Development Finished! Resulting Alpha2 to be released!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>4:45PM September 21, 2013</td>
		<td>- Alpha3 starts develop. This will be the Alphav1.0 Release for public!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>8:10PM September 21, 2013</td>
		<td>- Install.PHP now gets database connections and registers a admin user.</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>9:45AM September 22, 2013</td>
		<td>- Logout issue fixed!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>11:50AM September 22, 2013</td>
		<td>- Posting Finished!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>12:15PM September 22, 2013</td>
		<td>- Alpha Releasev1.0RC1 or Alpha3 is done! Offline Development finishes once again!</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>5:35PM September 23, 2013</td>
		<td>- Alpha Releasev1.0RC2 or Alpha4 is released as an attempt to fix the header and session issue.</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>6:35PM September 23, 2013</td>
		<td>- Alpha Releasev1.0RC3 or Alpha4_1 is released as a second attempt to fix the header and session issue.<br/>Also an update on all the files and removing the magic quotes on common.php.<br/>Progressing towards a config.php by modifing the .htacess with a sitedown.php.</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>6:35PM September 23, 2013</td>
		<td>- Alpha Releasev1.0RC4 or Alpha4_2 is released to fix link issues and admin.php</td>
                <td>Harry</td>
	  </tr>
          <tr>
		<td>6:00PM September 24, 2013</td>
		<td>- Alpha Releasev1.0RC5 or Alpha5 is released with tons of tweaks:<br/>1. Added Back Buttons to go back to Admin.PHP after making a post, editing account or looking at the release log.<br/>2. Made a Index.PHP where there is only the posts and no admin at all. This is for a full site view without any buttons.<br/> &nbsp Made this because the < hr >'s won't extend after hiding the admin panel. <br/>3. Removed the DirectoryIndex form .htaccess because Index.PHP (posts page) is where everyone should visit first.<br/>4. Edited the look of Admin.PHP. Good start to the new styling.<br/>5. Cleared Error logs.</td>
                <td>Harry</td>
	  </tr>
<tr>
		<td>9:30AM October 6, 2013</td>
		<td>- Alpha 1.0.0 Pre-release.</td>
                <td>Eric</td>
	  </tr>
	  </table>