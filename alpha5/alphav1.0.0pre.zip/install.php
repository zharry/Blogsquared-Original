<!DOCTYPE html>
<html>

<head>
<title>Blog Squared Installer</title>
<link rel="stylesheet" type="text/css" href="styles/defaultinstall.css">
</head>

<body>
<center><h2>Blog Squared Blog Engine Installer</h2>

<form action="install_control.php" method="post">
<h4>Database Information</h4>
Host: <input type="text" name="mysql_host"><br/>
Username: <input type="text" name="mysql_user"><br/>
Password: <input type="password" name="mysql_pass"><br/>
Database: <input type="text" name="mysql_database"><br/>
<h4>Admin Account Creation</h4>
Username: <input type="text" name="admin_user"><br/>
Email: <input type="text" name="admin_email"><br/>
Password: <input type="password" name="admin_pass"><br/>
<h4>Blog Squared Configuration</h4>
Blog Squared Config.PHP will be availiable in a later update! Check Again!<br/>
<input type="submit" value="GO!">
</form>

</center>
</body>
</html>